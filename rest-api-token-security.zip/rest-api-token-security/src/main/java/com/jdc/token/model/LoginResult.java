package com.jdc.token.model;

public record LoginResult(
    boolean success,
    String message
) {
}

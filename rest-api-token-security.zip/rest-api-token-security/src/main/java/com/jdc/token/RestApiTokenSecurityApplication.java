package com.jdc.token;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiTokenSecurityApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestApiTokenSecurityApplication.class, args);
    }

}

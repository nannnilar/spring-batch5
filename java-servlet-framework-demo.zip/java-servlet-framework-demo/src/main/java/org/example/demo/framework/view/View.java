package org.example.demo.framework.view;

import org.example.demo.framework.model.Model;

public interface View {
    String render(Model model);
}

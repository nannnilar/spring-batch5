package org.example.demo.framework.model;

public interface Model {
    void set(String name,String value);

    String get(String name);
}

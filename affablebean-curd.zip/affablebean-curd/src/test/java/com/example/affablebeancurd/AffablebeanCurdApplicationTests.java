package com.example.affablebeancurd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AffablebeanCurdApplicationTests {

    @Test
    void contextLoads() {
    }

}
